export const environment = {
  apiUrl: 'https://localhost:7225/api',
  GOOGLE_CLIENT_ID:'684593791243-oo3dr8js6etm1n00ohk8b5rsjvcmkk2e.apps.googleusercontent.com'
};
